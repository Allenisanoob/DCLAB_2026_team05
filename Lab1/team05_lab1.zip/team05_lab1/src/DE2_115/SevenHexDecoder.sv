module SevenHexDecoder (
	input        [8:0] i_bin,
	input              i_mode,       // 新增：模式切換 (接 SW[17])
	output logic [6:0] o_hex0,
	output logic [6:0] o_hex1,
	output logic [6:0] o_hex2,
	output logic [6:0] o_hex3,
	output logic [6:0] o_hex4,
	output logic [6:0] o_hex5,
	output logic [6:0] o_hex6,
	output logic [6:0] o_hex7
);

/* The layout of seven segment display, 1: dark
 *    00
 *   5  1
 *    66
 *   4  2
 *    33
 */
parameter D0 = 7'b1000000;
parameter D1 = 7'b1111001;
parameter D2 = 7'b0100100;
parameter D3 = 7'b0110000;
parameter D4 = 7'b0011001;
parameter D5 = 7'b0010010;
parameter D6 = 7'b0000010;
parameter D7 = 7'b1011000;
parameter D8 = 7'b0000000;
parameter D9 = 7'b0010000;
parameter DARK = 7'b1111111; // 全暗

logic [3:0] hun, ten, one;

// 將二進制數值轉換為各個位數
always_comb begin
    if (i_bin > 255) begin
        hun = 4'hA; // 超過 255 的情況，no顯示
        ten = 4'hA;
        one = 4'hA;
    end else if (i_bin < 10) begin
        hun = 4'hA;
        ten = 4'hA;     
        one = i_bin % 10;
    end else if (i_bin < 100) begin
        hun = 4'hA;
        ten = i_bin / 10;
        one = i_bin % 10;
    end else begin
        hun = i_bin / 100;
        ten = (i_bin % 100) / 10;
        one = i_bin % 10;
    end
end

// Function: BCD 轉 七段顯示器
function [6:0] bcd2seg(input [3:0] bcd);
    case(bcd)
        4'h0: bcd2seg = D0;
        4'h1: bcd2seg = D1;
        4'h2: bcd2seg = D2;
        4'h3: bcd2seg = D3;
        4'h4: bcd2seg = D4;
        4'h5: bcd2seg = D5;
        4'h6: bcd2seg = D6;
        4'h7: bcd2seg = D7;
        4'h8: bcd2seg = D8;
        4'h9: bcd2seg = D9;
        4'hA: bcd2seg = DARK;
        default: bcd2seg = DARK; // 預設為全暗
    endcase
endfunction

// 根據模式選擇輸出
always_comb begin
    if (i_mode) begin
        // SW[17] 為 1：二進位模式，由 HEX0 ~ HEX6 顯示 7 個 bit
        o_hex0 = i_bin[0] ? D1 : D0;
        o_hex1 = i_bin[1] ? D1 : D0;
        o_hex2 = i_bin[2] ? D1 : D0;
        o_hex3 = i_bin[3] ? D1 : D0;
        o_hex4 = i_bin[4] ? D1 : D0;
        o_hex5 = i_bin[5] ? D1 : D0;
        o_hex6 = i_bin[6] ? D1 : D0;
        o_hex7 = i_bin[7] ? D1 : D0; // 擴充至 8-bit 顯示
    end else begin
        // SW[17] 為 0：十進位模式，由 HEX0 ~ HEX2 顯示
        o_hex0 = bcd2seg(one);
        o_hex1 = bcd2seg(ten);
        o_hex2 = bcd2seg(hun);
        o_hex3 = DARK;
        o_hex4 = DARK;
        o_hex5 = DARK;
        o_hex6 = DARK;
        o_hex7 = DARK;
    end
end

endmodule