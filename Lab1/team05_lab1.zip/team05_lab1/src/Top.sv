module Top (
	input        i_clk,
	input        i_start,
	input        i_rst_n,
	input        i_cheat_start,	// 新增作弊按鈕

	input  [1:0] i_sw,          // 新增 Switch 輸入
	input  		 i_set_cheat_sw,
	input        i_set_target_sw,     	
	input  [7:0] i_set_num_sw,  // 新增數值 Switch 輸入
	
	output [2:0] o_state_led,
	output [7:0] o_match_led,
	output [8:0] o_random_out   // 亂數範圍0~255、擴充至 8+1-bit
);

	`ifdef FAST_SIM
		localparam INITIAL_THRESHOLD = 32'd100;
		localparam THRESHOLD_INC     = 32'd100;
		localparam FINAL_THRESHOLD   = 32'd50000;
		localparam BLINK_TIME = 32'd25000; // 0.5秒 (50kHz 時脈)
	`else
		localparam INITIAL_THRESHOLD = 32'd100000;
		localparam THRESHOLD_INC     = 32'd100000;
		localparam FINAL_THRESHOLD   = 32'd50000000;
		localparam BLINK_TIME = 32'd25000000; // 0.5秒 (50MHz 時脈)
	`endif

	logic [1:0] i_sw_r;
	logic i_set_cheat_sw_r, i_set_target_sw_r;
	logic [7:0] i_set_num_sw_w;

	always_ff @(posedge i_clk) begin
		i_sw_r <= i_sw;
		i_set_cheat_sw_r <= i_set_cheat_sw;
		i_set_target_sw_r <= i_set_target_sw;
	end

	logic [7:0] cheat_num_r, cheat_num_w;
	logic [7:0] target_num_r, target_num_w;

	
	localparam IDLE = 2'd0;
	localparam RUN  = 2'd1;
	localparam SET  = 2'd2;

	logic 		 cheating_r, cheating_w;
	logic        blink_control_r, blink_control_w; // 新增閃爍控制信號
	logic [1:0]  state_r, state_w;
	logic [31:0] counter_r, counter_w;
	logic [31:0] blink_counter_r, blink_counter_w; // 新增閃爍計數器
	logic [31:0] threshold_r, threshold_w;
	logic [7:0]  o_random_out_r, o_random_out_w;	// 亂數範圍0~255、擴充至 8-bit
	logic [7:0]  random_num; 	// 亂數範圍0~255、擴充至 8-bit

	Random random0(.i_clk(i_clk), .i_rst_n(i_rst_n), .o_random_num(random_num));

	assign o_random_out = {blink_control_r, o_random_out_r};
    assign i_set_num_sw_w = i_set_num_sw;

	always_comb begin
		state_w         = state_r;
		counter_w       = counter_r;
		threshold_w     = threshold_r;
		o_random_out_w  = o_random_out_r;
		target_num_w    = target_num_r;
		cheat_num_w     = cheat_num_r;
		blink_counter_w = blink_counter_r;
		blink_control_w = blink_control_r;
		cheating_w      = cheating_r;

		o_state_led = 3'b111;
		o_match_led = 8'b00000000;

		case(state_r)
			IDLE: begin
				o_state_led = 3'b001;
				counter_w   = 0;
				threshold_w = INITIAL_THRESHOLD;
				if(i_start) begin
					state_w = RUN;
				end else if (i_set_cheat_sw_r || i_set_target_sw_r) begin
					state_w = SET;
				end else if (i_cheat_start) begin
					cheating_w = 1'b1; // 進入作弊模式
					state_w = RUN;     // 直接進入 RUN 狀態
				end
				if (o_random_out_r == target_num_r && target_num_r != 8'd0) begin
					o_match_led = target_num_r; 
				end
			end

			RUN: begin
				o_state_led = 3'b010;
				o_match_led = 8'b0;
				if(counter_r >= threshold_r) begin
					counter_w = 0;
					if(threshold_r >= FINAL_THRESHOLD) begin
						state_w = IDLE;
					end else begin
						threshold_w = threshold_r + THRESHOLD_INC + (threshold_r >> 2);
					end
				end else begin
					counter_w = counter_r + 1;
				end
			end

			SET: begin
				o_state_led = 3'b100;
				o_match_led = 8'b0;
				if(i_set_cheat_sw_r || i_set_target_sw_r) begin
					state_w = SET; // 持續在 SET 狀態，直到 switch off
				end else begin
					state_w = IDLE; //  switch off 後回到 IDLE 狀態
					o_random_out_w = 0; // 回到 IDLE 狀態時，輸出重置為 0
					blink_control_w = 0; // 回到 IDLE 狀態時，閃爍控制重置
				end

				if(i_set_target_sw_r) begin
					target_num_w = i_set_num_sw_w; // 在 SET_TARGET 狀態下，設定目標數值
				end else if(i_set_cheat_sw_r) begin
					cheat_num_w = i_set_num_sw_w; // 在 SET 狀態下，設定作弊數值
				end

				if (blink_counter_r >= BLINK_TIME) begin
					blink_counter_w = 0;
					blink_control_w = ~blink_control_r	; // 閃爍效果
				end else begin
					blink_counter_w = blink_counter_r + 1;
				end
			end

			default: begin
				state_w = IDLE;
			end
		endcase
	end

	always_ff @(posedge i_clk or negedge i_rst_n) begin
		if (!i_rst_n) begin
			state_r        <= IDLE;
			cheating_r     <= 1'b0;
			counter_r      <= 0;
			threshold_r    <= INITIAL_THRESHOLD;
			cheat_num_r    <= 8'd0;
			target_num_r   <= 8'd0;
			o_random_out_r <= 8'd0;
		end else begin
			state_r     <= state_w;
			counter_r   <= counter_w;
			blink_counter_r <= blink_counter_w;
			threshold_r <= threshold_w;
			blink_control_r <= blink_control_w;
			target_num_r <= target_num_w;
			cheat_num_r <= cheat_num_w;

			if (i_cheat_start) begin
				cheating_r <= 1'b1; // 進入作弊模式
			end else if (state_r == IDLE) begin
				cheating_r <= 1'b0; // 在 IDLE 狀態下重置作弊狀態
			end

			if (state_r == RUN && counter_r == threshold_r) begin
				if (cheating_r && counter_r >= FINAL_THRESHOLD) begin
					o_random_out_r <= cheat_num_r;
				end else if (i_sw_r[1] && i_sw_r[0]) begin
					o_random_out_r <= {6'b000000, random_num[1:0]}; // SW1 和 SW0 都開啟：0~3
				end	else if (i_sw_r[1]) begin
					o_random_out_r <= random_num[7:0]; // SW1 開啟：0~255
				end else if (i_sw_r[0]) begin
					o_random_out_r <= {2'b00, random_num[5:0]};  // SW0 開啟：0~63
				end else begin
					o_random_out_r <= {4'b0000, random_num[3:0]};  // 皆關閉：預設 0~15
				end
			end else if (state_r == SET) begin
				if(state_w == IDLE) begin
					o_random_out_r <= o_random_out_w;
				end else begin
					o_random_out_r <= i_set_num_sw_w; // 在 SET 狀態下，輸出設定的數值
				end
			end else begin
				o_random_out_r <= o_random_out_w;
			end
		end
	end

endmodule

module Random(
	input        i_clk,
	input        i_rst_n,
	output [7:0] o_random_num   // 擴充至 8-bit (2^8 = 256，足以涵蓋 255)
);

	logic [15:0] lfsr1_r, lfsr1_w;
    logic [15:0] lfsr2_r, lfsr2_w;


	// 取後 8 個 bit 作為隨機輸出
    assign o_random_num = lfsr1_r[7:0] ^ lfsr2_r[7:0];

    always_comb begin
        // LFSR 1 & 2 
        lfsr1_w = {lfsr1_r[14:0], lfsr1_r[15] ^ lfsr1_r[13] ^ lfsr1_r[12] ^ lfsr1_r[10]};
        lfsr2_w = {lfsr2_r[14:0], lfsr2_r[15] ^ lfsr2_r[14] ^ lfsr2_r[12] ^ lfsr2_r[3]};
    end

    always_ff @(posedge i_clk or negedge i_rst_n) begin
        if (!i_rst_n) begin
            lfsr1_r <= 16'hACE1; // 設定 Seed 
            lfsr2_r <= 16'h1234;
        end else begin
            lfsr1_r <= lfsr1_w;
            lfsr2_r <= lfsr2_w;
        end
    end

endmodule